import { avarge, snakeCase, camelCase, HCF } from "./exercise_2.js";
import { evenAndOddCounter, pascalCase } from "./exercise_3.js";

const x = [4, 6, 8, 10, 2];
console.log("avarge: ", avarge(x));

console.log("snake case: ", snakeCase("hello wo r d  "));

console.log(
  "camel case: ",
  camelCase("hello world welcome to my couse programming"),
);

console.log("HCF: ", HCF(12, 18));

console.log("even And Odd Counter: ", evenAndOddCounter("1234567890"));

console.log("pascal case: ", pascalCase("hello to my world"));
